const express = require('express');
const createError = require('http-errors');
const dotenv = require('dotenv').config();

const app = express();

const logger = require('./utils/logger');

//middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Initialize DB
require('./config/database')();

app.use((req, res, next) => {
  next(createError(404, 'Not found'));
});

//Error handler
app.use((err, req, res, next) => {
  res.status(err.status || 500);
  res.send({
    error: {
      status: err.status || 500,
      message: err.message
    }
  });
});

//define port
const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log('Server is running on port : ' + PORT);
  logger.error('Server is running on port : ' + PORT);
});
