require("dotenv").config();
const mongoose = require('mongoose');

const logger = require('../utils/logger');

mongoose.set("strictQuery", false);

const connectDb = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        }, (err => {
            if (err) {
                console.log("Connection to database failed ")
                console.log(err)
            }
        }))
        logger.error("Connection to database success")

    } catch (error) {
        console.log("Error")
    }
}

module.exports = connectDb;
